import './App.css';
import Login from './Login/Login';
import Registtration from './Registration/Registtration';
import { Routes, Route } from 'react-router-dom';
import Verifyotp from './Registration/Verifyotp';
import SidebarHeader from './SidebarHeader/SidebarHeader';
import WelcomePage from './Registration/Welcome';
import { ApiProvider } from './Context/ApiContext';

function App() {
  // we will now get the subdomain , to find the user details
  const url = window.location.href
  // url  
  // https://<teanantName>.<DomainName>.com
  // https://tenantName ,domainName , com
  // split(".")->[ "https://tenantName ,domainName ,com"]
  const tenatName = url.split(".")[0].split("//")[1]
  return (
    <>
      <Routes>
        <Route path='/login' element={<Login />} />
        <Route path='/registration' element={<ApiProvider><Registtration /></ApiProvider>} />
        <Route path='/verifyotp/:email' element={<Verifyotp />} />
        <Route path='/welcome/:tenantId' element={<WelcomePage />} />
        <Route path='*' element={<SidebarHeader tenantName={tenatName} />} />
      </Routes>

    </>
  );
}

export default App;







